// Бургер-меню

const burger = document.getElementById('burger');
const nav = document.getElementById('nav');

burger.addEventListener('click', function () {
    burger.classList.toggle('active');
    nav.classList.toggle('active');
});

nav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
        burger.classList.remove('active');
        nav.classList.remove('active');
    });
});

document.addEventListener('click', function (event) {
    if (!burger.contains(event.target) && !nav.contains(event.target)) {
        burger.classList.remove('active');
        nav.classList.remove('active');
    }
});


// Модальное окно

const modal = document.getElementById('modal');
const modalClose = document.getElementById('modal-close');
const openButtons = document.querySelectorAll('.open-modal');

openButtons.forEach(function (button) {
    button.addEventListener('click', function () {
        modal.classList.add('active');
    });
});

modalClose.addEventListener('click', function () {
    modal.classList.remove('active');
});

modal.addEventListener('click', function (event) {
    if (event.target === modal) {
        modal.classList.remove('active');
    }
});


// Слайдер

const slides = document.querySelectorAll('.slide');
const nextButton = document.getElementById('next');
const prevButton = document.getElementById('prev');

let currentSlide = 0;

function showSlide(index) {
    slides.forEach(function (slide) {
        slide.classList.remove('active');
    });

    currentSlide = (index + slides.length) % slides.length;
    slides[currentSlide].classList.add('active');
}

nextButton.addEventListener('click', function () {
    showSlide(currentSlide + 1);
});

prevButton.addEventListener('click', function () {
    showSlide(currentSlide - 1);
});


// Вкладки услуг

const tabs = document.querySelectorAll('.tab');
const serviceLists = document.querySelectorAll('.services-list');

tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
        tabs.forEach(function (item) {
            item.classList.remove('active');
        });

        serviceLists.forEach(function (list) {
            list.classList.remove('active');
        });

        tab.classList.add('active');

        const tabId = tab.dataset.tab;
        document.getElementById(tabId).classList.add('active');
    });
});


// Аккордеон

const accordionItems = document.querySelectorAll('.accordion-item');

accordionItems.forEach(function (item) {
    const question = item.querySelector('.accordion-question');
    const answer = item.querySelector('.accordion-answer');

    question.addEventListener('click', function () {
        const isActive = item.classList.contains('active');

        accordionItems.forEach(function (otherItem) {
            otherItem.classList.remove('active');
            otherItem.querySelector('.accordion-answer').style.maxHeight = null;
        });

        if (!isActive) {
            item.classList.add('active');
            answer.style.maxHeight = answer.scrollHeight + 'px';
        }
    });
});


// Валидация формы

const form = document.getElementById('appointment-form');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');

const nameError = document.getElementById('name-error');
const emailError = document.getElementById('email-error');
const successMessage = document.getElementById('success-message');

form.addEventListener('submit', function (event) {
    event.preventDefault();

    let isValid = true;

    nameError.textContent = '';
    emailError.textContent = '';
    successMessage.textContent = '';

    if (nameInput.value.trim().length < 2) {
        nameError.textContent = 'Имя должно содержать минимум 2 символа';
        isValid = false;
    }

    if (!emailInput.value.includes('@')) {
        emailError.textContent = 'Введите корректный email';
        isValid = false;
    }

    if (isValid) {
        successMessage.textContent = 'Заявка на обработке, мы вам напишем';
        form.reset();
    }
});
