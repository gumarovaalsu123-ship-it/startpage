Сюда добавь изображения. Используй эти имена файлов или измени пути в index.html и style.css.

Баннеры:
- banner-1.jpg
- banner-2.jpg
- banner-3.jpg

Карточки услуг:
- adult-1.jpg
- adult-2.jpg
- adult-3.jpg
- children-1.jpg
- children-2.jpg
- children-3.jpg
