// ===== 1. БУРГЕР-МЕНЮ =====
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav');

function closeMenu() {
  burger.classList.remove('active');
  nav.classList.remove('active');
  burger.setAttribute('aria-expanded', 'false');
  burger.setAttribute('aria-label', 'Открыть меню');
}

burger.addEventListener('click', () => {
  burger.classList.toggle('active');
  nav.classList.toggle('active');
  const isOpen = burger.classList.contains('active');
  burger.setAttribute('aria-expanded', isOpen);
  burger.setAttribute('aria-label', isOpen ? 'Закрыть меню' : 'Открыть меню');
});

nav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', closeMenu);
});

document.addEventListener('click', (e) => {
  if (!nav.contains(e.target) && !burger.contains(e.target)) {
    closeMenu();
  }
});

// ===== 2. МОДАЛЬНОЕ ОКНО =====
const modal = document.querySelector('.modal');
const openModalButtons = document.querySelectorAll('.open-modal');
const closeModalButton = document.querySelector('.modal__close');

function openModal() {
  modal.classList.add('active');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modal.classList.remove('active');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

openModalButtons.forEach(button => {
  button.addEventListener('click', openModal);
});

closeModalButton.addEventListener('click', closeModal);

modal.addEventListener('click', (e) => {
  if (e.target === modal) closeModal();
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeModal();
    closeMenu();
  }
});

// ===== 3. БЕСКОНЕЧНЫЙ СЛАЙДЕР =====
const slides = document.querySelectorAll('.slide');
const nextButton = document.querySelector('.next');
const prevButton = document.querySelector('.prev');
let index = 0;

function showSlide() {
  slides.forEach(slide => slide.classList.remove('active'));
  slides[index].classList.add('active');
}

nextButton.addEventListener('click', () => {
  index++;
  if (index >= slides.length) index = 0;
  showSlide();
});

prevButton.addEventListener('click', () => {
  index--;
  if (index < 0) index = slides.length - 1;
  showSlide();
});

// ===== 4. ВКЛАДКИ УСЛУГ =====
const tabs = document.querySelectorAll('.tab');
const contents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(item => {
      item.classList.remove('active');
      item.setAttribute('aria-selected', 'false');
    });
    contents.forEach(content => {
      content.classList.remove('active');
      content.hidden = true;
    });

    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    const currentContent = document.getElementById(tab.dataset.tab);
    currentContent.classList.add('active');
    currentContent.hidden = false;
  });
});

// ===== 5. АККОРДЕОН =====
const items = document.querySelectorAll('.acc-item');

items.forEach(item => {
  const head = item.querySelector('.acc-head');

  head.addEventListener('click', () => {
    const isOpen = item.classList.contains('active');

    items.forEach(otherItem => {
      otherItem.classList.remove('active');
      otherItem.querySelector('.acc-head').setAttribute('aria-expanded', 'false');
    });

    if (!isOpen) {
      item.classList.add('active');
      head.setAttribute('aria-expanded', 'true');
    }
  });
});

// ===== 6. ВАЛИДАЦИЯ ФОРМЫ =====
const form = document.querySelector('.modal__form');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const success = document.querySelector('.success');
let formWasSubmitted = false;

function validateForm() {
  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  let isValid = true;

  nameError.textContent = '';
  emailError.textContent = '';

  if (name.length < 2) {
    nameError.textContent = 'Имя должно содержать минимум 2 символа';
    isValid = false;
  }

  if (!email.includes('@')) {
    emailError.textContent = 'Email должен содержать символ @';
    isValid = false;
  }

  return isValid;
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  formWasSubmitted = true;
  success.textContent = '';

  if (validateForm()) {
    success.textContent = 'Заявка на обработке, мы вам напишем';
  }
});

[nameInput, emailInput].forEach(input => {
  input.addEventListener('input', () => {
    if (formWasSubmitted) {
      const isValid = validateForm();
      if (isValid) {
        success.textContent = 'Заявка на обработке, мы вам напишем';
      } else {
        success.textContent = '';
      }
    }
  });
});
